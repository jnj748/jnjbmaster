# 건축물대장 API 소스 내보내기

관리의달인 프로젝트에서 건축물대장 전유부(getBrExposPubuseAreaInfo) API 연동 및 호실명단 생성에 사용되는 서버·클라이언트·테스트 소스를 묶은 패키지입니다.

대상 프로젝트에 표제부(getBrTitleInfo)와 카카오 지오코딩이 이미 구현되어 있고, 전유부 API 연동만 추가하려는 경우 이 파일들을 참고하세요.

---

## 파일 구조 및 역할

### 서버 — 핵심 API 로직

| 파일 | 역할 |
|------|------|
| `artifacts/api-server/src/routes/buildings/register-lookup.ts` | 표제부(getBrTitleInfo) + 전유부(getBrExposPubuseAreaInfo) API 호출. 페이징, BigInt PK 정밀도 보존(`preserveBigIntegerIds`), 호실 그룹핑(`groupAreaInfoItems`), 토지식별자 기반 조회(`fetchAreaInfoByLandCode`), PK 기반 폴백(`fetchAreaInfoFromRegister`), 다동 순회(`fetchAreaInfoForAllDongs`), 건물종류 분류(`classifyRegisterBuildingKind`) |
| `artifacts/api-server/src/routes/buildings/units-import.ts` | 전유부 응답 → units DB 일괄 upsert. 미리보기(dryRun)/확정(previewToken) 분리, 층 정규화(`normalizeFloor`), 소유자 자동채움 |
| `artifacts/api-server/src/routes/buildings/units-import-cache.ts` | 미리보기 결과 인메모리 캐시. previewToken 발급/소비로 확정 단계에서 외부 API 재호출 없이 적용 |
| `artifacts/api-server/src/routes/buildings/owner-lookup.ts` | 소유자 자동조회 best-effort 래퍼. 현재 no-op이며 어댑터 교체 설계 |

### 서버 — 카카오 지오코딩

| 파일 | 역할 |
|------|------|
| `artifacts/api-server/src/lib/kakaoGeocode.ts` | 도로명 → 좌표 변환 헬퍼 (카카오 로컬 API) |
| `artifacts/api-server/src/routes/kakaoGeocode.ts` | 지오코딩 프록시 라우트. KAKAO_REST_API_KEY를 서버에서만 사용 |

### 클라이언트 — UI 컴포넌트

| 파일 | 역할 |
|------|------|
| `artifacts/manager-app/src/lib/building-register-labels.ts` | 표제부/총괄표제부 한국어 라벨·포매터. 화이트리스트 그룹 + 자동 "기타" 그룹 |
| `artifacts/manager-app/src/components/building-register/building-expose-areas-card.tsx` | 전유부 호실별 면적 표시 카드 (동별 그룹핑, 테이블 렌더링) |
| `artifacts/manager-app/src/components/building-register/building-register-details-card.tsx` | 표제부 상세정보 카드 (그룹별 필드 표시) |

### 테스트

| 파일 | 검증 대상 |
|------|-----------|
| `registerLookup-approvalDate.test.ts` | 사용승인일(useAprDay) YYYYMMDD → ISO 변환 |
| `registerLookup-areaInfoGrouping.test.ts` | 전유부 응답 호실 단위 그룹핑·합산 (전유/공용 분리) |
| `registerLookup-areaInfoLandCode.test.ts` | 토지식별자 기반 전유부 조회 로직 |
| `registerLookup-pkPrecision.test.ts` | BigInt PK 정밀도 보존 (preserveBigIntegerIds) |
| `registerLookup-repairPks.test.ts` | 손상된 PK 식별·복구 엔드포인트 |
| `unitsImport-noUnitData.test.ts` | 일반건축물 등 전유부 자료 없는 경우 처리 |
| `unitsImport-previewToken.test.ts` | 미리보기/확정 분리 흐름 (previewToken 발급·소비·만료) |
| `building-register-labels.test.ts` | 한국어 라벨·포매터·자동 기타 그룹 |

---

## 필요한 환경변수

| 변수 | 용도 | 발급처 |
|------|------|--------|
| `BUILDING_REGISTER_API_KEY` | 공공데이터포털 건축물대장 API 인증키 | [data.go.kr](https://www.data.go.kr/) |
| `KAKAO_REST_API_KEY` | 카카오 로컬 API (도로명 → 좌표) | [developers.kakao.com](https://developers.kakao.com/) |
| `BUILDING_OWNER_API_KEY` | (선택) 소유자 자동조회 API 키. 미설정 시 소유자 조회 건너뜀 | — |

---

## 공공데이터포털 API 엔드포인트

| API | 엔드포인트 | 용도 |
|-----|-----------|------|
| 건축물대장 표제부 | `https://apis.data.go.kr/1613000/BldRgstHubService/getBrTitleInfo` | 건물 기본정보, 동별 PK 추출 |
| 건축물대장 총괄표제부 | `https://apis.data.go.kr/1613000/BldRgstHubService/getBrRecapTitleInfo` | 단지 전체 요약 (대지면적, 용적률 등) |
| 건축물대장 전유부 | `https://apis.data.go.kr/1613000/BldRgstHubService/getBrExposPubuseAreaInfo` | 호실별 전용/공용 면적 |

공통 파라미터: `serviceKey`, `sigunguCd`, `bjdongCd`, `bun`, `ji`, `numOfRows`, `pageNo`, `_type=json`
전유부 추가 파라미터: `mgmBldrgstPk` (PK 기반 조회 시)

---

## 대상 프로젝트 적용 가이드

### 1. 전유부 호출 함수 추가

`register-lookup.ts`에서 핵심 함수를 참고하여 대상 프로젝트의 `buildingRegistry.ts` 패턴에 맞춰 추가:

- **`fetchAreaInfoByLandCode(params)`** — 토지식별자(시군구·법정동·본번·부번)로 전유부 조회. 단지 전체 동/호실이 한 번에 내려옴. 정상 경로.
- **`fetchAreaInfoFromRegister(mgmBldrgstPk)`** — 표제부 PK로 전유부 조회. 토지식별자가 없는 레거시 폴백.
- **`groupAreaInfoItems(items)`** — 전유부 raw 응답(호실당 N행: 전유 1 + 공용 N)을 호실 단위 1행으로 그룹핑·합산.
- **`preserveBigIntegerIds(jsonText)`** — JSON 파싱 전 큰 정수 식별자를 문자열로 감싸 정밀도 손실 방지.

### 2. mock 데이터 → 실제 API 교체

대상 프로젝트의 `import-registry` 엔드포인트에서:

1. mock 데이터를 반환하는 부분을 `fetchAreaInfoByLandCode()` 호출로 교체
2. 응답이 비어 있으면 `fetchAreaInfoFromRegister(pk)` 폴백 시도
3. `groupAreaInfoItems()`로 호실 단위 정규화 후 DB upsert

### 3. 주의사항

- **BigInt PK 정밀도**: `JSON.parse` 전에 반드시 `preserveBigIntegerIds()`를 적용. 미적용 시 16자리 이상 정수 PK가 손상되어 후속 API 호출 실패.
- **페이징**: 공공데이터 API는 페이지당 최대 100건. `totalCount` 기반으로 끝까지 순회 필요.
- **일반건축물**: `regstrGbCdNm`이 "일반"인 건물은 전유부 자료가 없는 것이 정상. API 오류와 구분 필요.
- **호실 그룹핑**: 전유부 응답은 호실당 여러 행(전유 1행 + 공용 N행)으로 내려오므로, `groupAreaInfoItems()`로 합산하지 않으면 중복 호실 표시 및 공용면적 누락 발생.
- **DB 스키마/마이그레이션**: 이 ZIP에 포함되지 않음. 프로젝트별 스키마에 맞춰 별도 작업 필요.
- **인증/Express 설정**: 이 ZIP에 포함되지 않음. 기존 프레임워크 보일러플레이트에 맞춰 라우트 등록.
